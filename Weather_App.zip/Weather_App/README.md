# FiveDayWeather
This is an application utilising Dagger 2 aswell as RESTfull api in order to dispaly wether for the week.
