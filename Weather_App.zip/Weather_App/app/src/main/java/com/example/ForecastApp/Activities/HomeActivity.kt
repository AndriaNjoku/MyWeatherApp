package com.example.ForecastApp.Activities

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.ForecastApp.Fragments.WeatherFragment
import com.example.ForecastApp.R
import com.example.ForecastApp.mvp.WeatherFragment.MainActivityContract
import javax.inject.Inject

class HomeActivity : AppCompatActivity(), MainActivityContract.View {

    @Inject
    lateinit var presenter: MainActivityContract.Presenter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        presenter.attach(this)
    }



    override fun showError(throwable: Throwable) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun showWeatherFragment() {

        supportFragmentManager.beginTransaction()
                .replace(R.id.frame, WeatherFragment().newInstance() ,"weather")
                .commit()
    }

    override fun showDetailFragment() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

}


