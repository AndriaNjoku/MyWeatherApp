package com.example.ForecastApp.mvp.WeatherFragment

import com.example.ForecastApp.model.Objects.Day
import com.example.ForecastApp.mvp.BaseContract


interface WeatherFragmentContract{

    interface View : BaseContract.View {

        fun showForecast(days: List<Day>)
        fun showError(throwable: Throwable)
        fun showProgress(shouldShow: Boolean)
        fun showTryAgain(shouldShow: Boolean)
        fun injectDependencies()
        fun setActivityTitle(name: String?) {

        }
    }

    interface Presenter :BaseContract.Presenter<View>{
        fun getForecast(isOnline: Boolean)
        fun start()
        fun stop()
    }
}
