package com.example.ForecastApp.Fragments

import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.content.Context
import android.os.Bundle

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import butterknife.BindView
import butterknife.ButterKnife
import butterknife.OnClick
import butterknife.Unbinder
import com.example.ForecastApp.Activities.HomeActivity
import com.example.ForecastApp.Dagger_Activity.FragmentModule
import com.example.ForecastApp.DataBank.Utils
import com.example.ForecastApp.R
import com.example.ForecastApp.adapter.WeatherAdapter
import com.example.ForecastApp.application.App
import com.example.ForecastApp.model.Objects.Day
import com.example.ForecastApp.mvp.WeatherFragment.MainActivityContract
import com.example.ForecastApp.mvp.WeatherFragment.WeatherFragmentContract
import javax.inject.Inject



class WeatherFragment : Fragment(), WeatherFragmentContract.View {

    @Inject
    lateinit var presenter: WeatherFragmentContract.Presenter

    private val forecastAdapter = WeatherAdapter()

    lateinit var activityContext: Context

    val myActivityView= activityContext as MainActivityContract.View

    var binder: Unbinder? = null

    @BindView(R.id.rv_forecast)
    internal var recyclerView: RecyclerView? = null
    @BindView(R.id.pb_home_progress)
    internal var progressBar: ProgressBar? = null
    @BindView(R.id.tv_try_again)
    internal var tryAgain: TextView? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        injectDependencies()
        val view =inflater.inflate(R.layout.weather_frame,container,false)
        binder = ButterKnife.bind(view)
            recyclerView!!.layoutManager = LinearLayoutManager(activityContext)
            recyclerView!!.adapter = forecastAdapter
        presenter.attach(this)
        presenter.getForecast(Utils.isOnline(activityContext))

        return view

    }

    override fun showForecast(days: List<Day>) {
        forecastAdapter.setData(days)
    }

    override fun injectDependencies() {
        App.instance.component.plus(FragmentModule()).inject(this)
    }


    override fun showError(throwable: Throwable) {
        throwable.printStackTrace()
        myActivityView.showError(throwable)
    }

    override fun showProgress(shouldShow: Boolean) {
        progressBar!!.visibility = if (shouldShow) View.VISIBLE else View.GONE
    }

    override fun setActivityTitle(name: String?){


    }

    override fun showTryAgain(shouldShow: Boolean) {
        if (shouldShow) {
            recyclerView!!.visibility = View.GONE
            tryAgain!!.visibility = View.VISIBLE
        } else {
            tryAgain!!.visibility = View.GONE
            recyclerView!!.visibility = View.VISIBLE
        }
    }


    @OnClick(R.id.tv_try_again)
    fun onTryAgainClicked() {
        presenter.getForecast(Utils.isOnline(activityContext))
    }

    override fun onStop() {
        super.onStop()
        presenter.stop()
    }
    fun newInstance(): WeatherFragment{

        return WeatherFragment()
    }
}





