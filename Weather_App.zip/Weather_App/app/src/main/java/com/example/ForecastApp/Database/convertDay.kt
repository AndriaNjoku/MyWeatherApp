package com.example.ForecastApp.Database

import android.arch.persistence.room.TypeConverter

import com.example.ForecastApp.model.Objects.Day
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

import java.lang.reflect.Type
import java.util.Collections

object convertDay {

    @TypeConverter
    fun ltString(days: List<Day>): String {
        return Gson().toJson(days)
    }


    @TypeConverter
    fun stringtl(data: String?): List<Day> {
        val gson = Gson()
        if (data == null) {
            return emptyList()
        }
        val type = object : TypeToken<List<Day>>() {

        }.type
        return gson.fromJson(data, type)
    }


}
