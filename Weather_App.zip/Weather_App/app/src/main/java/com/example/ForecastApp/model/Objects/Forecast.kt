package com.example.ForecastApp.model.Objects

import android.arch.persistence.room.Embedded
import android.arch.persistence.room.Entity
import android.arch.persistence.room.PrimaryKey
import android.arch.persistence.room.TypeConverters

import com.example.ForecastApp.Database.convertDay
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

@Entity
class Forecast {
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

    @SerializedName("cod")
    @Expose
    var cod: String? = null

    @SerializedName("message")
    @Expose
    var message: Double = 0.toDouble()

    @SerializedName("cnt")
    @Expose
    var cnt: Int = 0

    @TypeConverters(convertDay::class)
    @SerializedName("list")
    @Expose
    var days: List<Day>? = null

    @Embedded
    @SerializedName("city")
    @Expose
    var city: City? = null
}
