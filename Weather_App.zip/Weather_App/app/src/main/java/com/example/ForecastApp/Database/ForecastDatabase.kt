package com.example.ForecastApp.Database

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase

import com.example.ForecastApp.model.Objects.Forecast

@Database(entities = [Forecast::class], version = 1)
abstract class ForecastDatabase : RoomDatabase() {
    abstract fun forecastDao(): ForecastOpp
}
