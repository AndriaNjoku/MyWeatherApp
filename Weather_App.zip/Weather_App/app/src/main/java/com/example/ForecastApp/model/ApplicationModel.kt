package com.example.minimoneybox.model

import com.example.ForecastApp.DataBank.Constants
import com.example.ForecastApp.Database.ForecastDatabase
import com.example.ForecastApp.Network.ForecastService
import com.example.ForecastApp.model.Objects.Day
import com.example.ForecastApp.model.Objects.Forecast
import com.example.ForecastApp.mvp.WeatherFragment.WeatherFragmentContract
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.functions.Action
import io.reactivex.functions.Consumer
import io.reactivex.schedulers.Schedulers

class ApplicationModel (private val myService: ForecastService
                        , private val myDatabase: ForecastDatabase
                        ): ApplicationModelContract {

    private lateinit var myWeatherView: WeatherFragmentContract.View
    private val compositeDisposable: CompositeDisposable = CompositeDisposable()

    private//Maybe completes without emitting anything when the table is empty
    val forecastFromDb: Observable<Forecast>
        get() = myDatabase.forecastDao()
                .forecast
                .observeOn(AndroidSchedulers.mainThread())
                .doOnComplete { this.handleEmptyDb() }
                .toObservable()

    private val forecastFromAPI: Observable<Forecast>
        get() = myService.getFiveDayForecast(Constants.CITY_ID, Constants.API_KEY)
                .doOnNext { this.addToDb(it) }


    //we pass the weather view here given context
    override fun getForecast(isOnline: Boolean, view : WeatherFragmentContract.View) {

        this.myWeatherView=view
        val observable = if (isOnline) forecastFromAPI else forecastFromDb
        compositeDisposable.add(observable
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .doOnNext { forecast -> view.setActivityTitle(forecast.city?.name) }
                .map { forecast -> forecast.days }
                .doOnSubscribe { view.showProgress(true) }
                .doOnTerminate { view.showProgress(false) }
                .doOnError{ error -> view.showError(error)}
                .subscribe{ result -> this.handleResult(result!!) })

    }

    override fun start() {}

    override fun stop() {
        compositeDisposable.clear()
    }
    override fun handleEmptyDb() {
        handleResult(emptyList())
    }

    //here also the weather view is concerned, since this method only gets called after getweather is called we
    //we can assign the view that is passed through that method
    override fun handleResult(days: List<Day>) {
        if (days.isEmpty()) {
            myWeatherView.showTryAgain(true)
        } else {
            myWeatherView.showTryAgain(false)
            myWeatherView.showForecast(days)
        }
    }

    override fun addToDb(forecast: Forecast) {
        myDatabase.forecastDao()
                .insertForecasts(forecast)
    }

}