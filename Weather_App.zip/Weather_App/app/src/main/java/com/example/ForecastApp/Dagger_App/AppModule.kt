package com.example.ForecastApp.Dagger_App

import android.app.Application
import android.arch.persistence.room.Room
import android.content.Context

import com.example.ForecastApp.Database.ForecastDatabase

import javax.inject.Singleton

import dagger.Module
import dagger.Provides

@Module
class AppModule(private val app: Application) {

    @Provides
    @Singleton
    fun provideApplicationContext(): Context {
        return app
    }

    @Provides
    @Singleton
    fun provideForecastDatabase(context: Context): ForecastDatabase {
        return Room.databaseBuilder(context, ForecastDatabase::class.java, "forecast").build()
    }

}
