package com.example.ForecastApp.mvp.WeatherFragment

import com.example.ForecastApp.DataBank.Constants
import com.example.ForecastApp.Database.ForecastDatabase
import com.example.ForecastApp.model.Objects.Day
import com.example.ForecastApp.model.Objects.Forecast
import com.example.ForecastApp.Network.ForecastService
import com.example.minimoneybox.model.ApplicationModelContract

import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class DetailFragmentPresenter(private val ModelInteractor: ApplicationModelContract) : DetailFragmentContract.Presenter {
    override fun attach(view: DetailFragmentContract.View) {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun detatchView() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun getWeatherDetails() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }


}
