package com.example.ForecastApp.Dagger_Activity

import com.example.ForecastApp.Dagger_App.AppComponent
import com.example.ForecastApp.Activities.HomeActivity

import dagger.Component

@FragmentScope
@Component(modules = [ActivityModule::class], dependencies = [AppComponent::class])
interface ActivityComponent {
    fun inject(homeActivity: HomeActivity)
}
