package com.example.minimoneybox.model


import com.example.ForecastApp.model.Objects.Day
import com.example.ForecastApp.model.Objects.Forecast
import com.example.ForecastApp.mvp.WeatherFragment.WeatherFragmentContract


interface ApplicationModelContract {

    fun getForecast(isOnline: Boolean,view: WeatherFragmentContract.View)

    fun start()

    fun stop()

    fun handleResult(days: List<Day>)

    fun addToDb(forecast: Forecast)

    fun handleEmptyDb()

}
