package com.example.ForecastApp.Fragments

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment

import butterknife.ButterKnife
import butterknife.Unbinder
import com.example.ForecastApp.Dagger_Activity.FragmentModule
import com.example.ForecastApp.application.App
import com.example.ForecastApp.mvp.WeatherFragment.DetailFragmentContract

import javax.inject.Inject


class DetailFragment : Fragment(), DetailFragmentContract.View {

    @Inject
    lateinit var presenter: DetailFragmentContract.Presenter



    override fun showWeatherDetails() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    private var unbinder: Unbinder? = null


    lateinit var myActivity: Context


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        injectDependencies()
       // val view = inflater.inflate(R.layout.activity_profile, container, false)

       // unbinder = ButterKnife.bind(this, view)

        presenter.attach(this)

        return view
    }

    private fun injectDependencies() {
        App.instance.component.plus(FragmentModule()).inject(this)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        this.myActivity=context

    }
    override fun onDetach() {
        super.onDetach()
        unbinder?.unbind()
    }






}
