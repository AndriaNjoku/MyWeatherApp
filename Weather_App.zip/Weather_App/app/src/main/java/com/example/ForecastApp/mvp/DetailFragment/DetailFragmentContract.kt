package com.example.ForecastApp.mvp.WeatherFragment

import com.example.ForecastApp.model.Objects.Day
import com.example.ForecastApp.mvp.BaseContract


interface DetailFragmentContract {

    interface View :BaseContract.View{

        fun showWeatherDetails()


    }

    interface Presenter: BaseContract.Presenter<View> {
        fun getWeatherDetails()
    }
}
