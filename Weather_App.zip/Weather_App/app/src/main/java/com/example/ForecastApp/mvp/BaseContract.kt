package com.example.ForecastApp.mvp



class BaseContract {


    interface Presenter<in T> {

        fun attach(view: T)

        fun detatchView()
    }

    interface View {

    }

}