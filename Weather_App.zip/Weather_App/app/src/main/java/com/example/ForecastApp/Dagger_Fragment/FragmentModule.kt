package com.example.ForecastApp.Dagger_Activity


import com.example.ForecastApp.mvp.WeatherFragment.DetailFragmentContract
import com.example.ForecastApp.mvp.WeatherFragment.DetailFragmentPresenter
import com.example.ForecastApp.mvp.WeatherFragment.WeatherFragmentContract
import com.example.ForecastApp.mvp.WeatherFragment.WeatherFragmentPresenter
import com.example.minimoneybox.model.ApplicationModelContract

import dagger.Module
import dagger.Provides

@Module
class FragmentModule(){

    @Provides
    @FragmentScope
    internal fun provideWeatherPresenter(mymodelinteractor: ApplicationModelContract): WeatherFragmentContract.Presenter {

        return WeatherFragmentPresenter(mymodelinteractor)
    }

    @Provides
    @FragmentScope
    internal fun provideDetailPresenter(myModelInteractor: ApplicationModelContract): DetailFragmentContract.Presenter {

        return DetailFragmentPresenter(myModelInteractor)
    }


}


