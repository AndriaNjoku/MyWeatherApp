package com.example.ForecastApp.model.Objects

import android.arch.persistence.room.Embedded
import android.arch.persistence.room.TypeConverters

import com.example.ForecastApp.Database.convertWeatherType
import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class Day {
    @SerializedName("dt")
    @Expose
    var dateAndTime: Long = 0

    @SerializedName("main")
    @Expose
    var main: Main? = null

    @TypeConverters(convertWeatherType::class)
    @SerializedName("weather")
    @Expose
    var weather: List<Weather>? = null

    @Embedded
    @SerializedName("clouds")
    @Expose
    var clouds: Clouds? = null

    @Embedded
    @SerializedName("wind")
    @Expose
    var wind: Wind? = null
}
