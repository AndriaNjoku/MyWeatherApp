package com.example.ForecastApp.mvp.WeatherFragment

import com.example.ForecastApp.DataBank.Constants
import com.example.ForecastApp.Database.ForecastDatabase
import com.example.ForecastApp.model.Objects.Day
import com.example.ForecastApp.model.Objects.Forecast
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.functions.Consumer
import io.reactivex.schedulers.Schedulers

class MainActivityPresenter() : MainActivityContract.Presenter {


    lateinit var myView: MainActivityContract.View

    override fun attach(view: MainActivityContract.View) {
        this.myView=view
        view.showWeatherFragment()
    }

    override fun start() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun stop() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun detatchView() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }





}
