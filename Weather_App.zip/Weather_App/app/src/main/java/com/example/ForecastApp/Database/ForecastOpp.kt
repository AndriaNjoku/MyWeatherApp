package com.example.ForecastApp.Database

import android.arch.persistence.room.Dao
import android.arch.persistence.room.Insert
import android.arch.persistence.room.OnConflictStrategy
import android.arch.persistence.room.Query

import com.example.ForecastApp.model.Objects.Forecast

import io.reactivex.Maybe

@Dao
interface ForecastOpp {

    @get:Query("SELECT * FROM forecast")
    val forecast: Maybe<Forecast>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertForecasts(vararg forecasts: Forecast)
}
