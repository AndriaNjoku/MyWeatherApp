package com.example.ForecastApp.Dagger_Activity

import com.example.ForecastApp.mvp.WeatherFragment.MainActivityContract
import com.example.ForecastApp.mvp.WeatherFragment.MainActivityPresenter


import dagger.Module
import dagger.Provides

@Module
class ActivityModule(private val homeView: MainActivityContract.View) {

    @Provides
    @ActivityScope
    internal fun provideActivityPresenter(myActivityView: MainActivityContract.View): MainActivityContract.Presenter {

        return MainActivityPresenter()
    }
}
