package com.example.ForecastApp.mvp.WeatherFragment

import com.example.ForecastApp.DataBank.Constants
import com.example.ForecastApp.Database.ForecastDatabase
import com.example.ForecastApp.model.Objects.Day
import com.example.ForecastApp.model.Objects.Forecast
import com.example.ForecastApp.Network.ForecastService
import com.example.minimoneybox.model.ApplicationModelContract

import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.schedulers.Schedulers

class WeatherFragmentPresenter(private val myModelInteractor: ApplicationModelContract) : WeatherFragmentContract.Presenter {

    lateinit var myView: WeatherFragmentContract.View

    override fun attach(view: WeatherFragmentContract.View) {
        this.myView=view

    }

    override fun detatchView() {
        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
    }

    override fun getForecast(isOnline: Boolean) {

        myModelInteractor.getForecast(isOnline,myView)
    }

    override fun start() {
       myModelInteractor.start()
    }

    override fun stop() {
       myModelInteractor.stop()
    }


}
