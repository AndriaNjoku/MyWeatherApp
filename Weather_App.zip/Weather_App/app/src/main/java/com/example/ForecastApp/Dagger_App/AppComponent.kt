package com.example.ForecastApp.Dagger_App

import android.app.Application
import com.example.ForecastApp.Dagger_Activity.FragmentComponent
import com.example.ForecastApp.Dagger_Activity.FragmentModule
import com.example.ForecastApp.Database.ForecastDatabase
import com.example.ForecastApp.Network.ForecastService
import com.example.minimoneybox.model.ApplicationModelContract

import javax.inject.Singleton

import dagger.Component

@Singleton
@Component(modules = [AppModule::class, NetworkModule::class])
interface AppComponent {

    fun provideModelInteractor(myService: ForecastService,myDatabase: ForecastDatabase): ApplicationModelContract

    fun inject(app: Application)

    fun plus(mySubmodule2: FragmentModule): FragmentComponent
}
