package com.example.ForecastApp.Dagger_Activity

import com.example.ForecastApp.Dagger_App.AppComponent
import com.example.ForecastApp.Fragments.DetailFragment
import com.example.ForecastApp.Fragments.WeatherFragment

import dagger.Component

@FragmentScope
@Component(modules = [FragmentModule::class], dependencies = [AppComponent::class])

interface FragmentComponent {

    fun inject(detailFragment: DetailFragment)

    fun inject(weatherFragment: WeatherFragment)
}
