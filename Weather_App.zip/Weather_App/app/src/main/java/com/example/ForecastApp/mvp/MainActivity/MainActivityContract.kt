package com.example.ForecastApp.mvp.WeatherFragment

import com.example.ForecastApp.mvp.BaseContract


interface MainActivityContract {

    interface View :BaseContract.View{

        fun showError(throwable: Throwable)
        fun showWeatherFragment()
        fun showDetailFragment()

    }

    interface Presenter : BaseContract.Presenter<View>{

        fun start()
        fun stop()

    }
}
